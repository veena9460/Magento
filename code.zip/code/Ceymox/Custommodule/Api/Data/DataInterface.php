<?php 
namespace Ceymox\Custommodule\Api\Data;

interface DataInterface
{
	/**
	*constant for keys of data array.Identical  to the name of t
}he getter in snake case
*/
const DATA_ID 			=	'data_id';
const DATA_TITLE		= 	'data_title';
const DATA_DESCRIPTION	=	'data_description';
const IS_ACTIVE			=	'is_active';

/**
* Get ID
*
* @return int|null
*/
public function getId();

/**
* set ID
* 
* @param $id
* @return DataInterface
*/
public function setId($id);

/**
* Get Data Title
* 
* @return string
*/
public function getDataTitle();

/**
* set Data Title
* 
* @param $title
* @return mixed
*/
public function setDataTitle($title);

/**
* Get Data Description
*
* @return mixed
*/
public function getDataDescription();


/**
* Set Data Description 
* 
* @param $description
* @return mixed
*/
public function setDataDescription($description);

/**
* Get is active
* 
* @return bool|int
*/
public function getIsActive();


/**
* Set is active
* 
* @param $isActive
* @return DataInterface
*/
public function setIsActive($isActive);

}

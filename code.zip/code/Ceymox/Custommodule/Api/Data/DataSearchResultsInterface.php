<?php 
namespace Ceymox\Custommodule\Api\Data;

use MAgento\Framework\Api\SearchResultInterface;

use Magento\Framework\Api\SearchResultsInterface;

interface DataSearchResultsInterface extends SearchResultsInterface
{
	/**
	* Get data list.
	*
	* @return \Ceymox\Coustommodule\Api\Data\DataInterface[]
	*/
	public function getItems();

	/**
	* set data list
	*
	* @param \Ceymox\Custommodule\Api\Data\DataInterface[] $items
	* @return $this
	*/
	public function setItems(array $items);
}

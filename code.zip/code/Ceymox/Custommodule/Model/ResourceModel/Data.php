<?php 
declare(strict_types=1);
namespace Ceymox\Custommodule\Model\ResourceModel;
use Magento\Framework\Model\ResourceModel\Db\Context;
use Magento\Framework\Model\ResourceModel\Db\AbstarctDb;
class Data extends AbstractDb
{
    /**
     * Data constructor.
     * @param Context $context
     */
    public function __construct(
        Context $context
    ) {
        parent::__construct($context);
    }

    /**
     * Resource initialisation
     */
    protected function _construct()
    {
        $this->_init('example_sample_data', 'data_id');
    }
}

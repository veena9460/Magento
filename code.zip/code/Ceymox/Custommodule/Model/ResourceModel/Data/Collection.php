<?php 
declare(strict_types=1);
namespace Ceymox\Custommodule\Model\ResourceModel\Data;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'data_id';

    /**
     * Collection initialisation
     */

     protected function _construct()
    {
        $this->_init('Ceymox\Custommodule\Model\Data','Ceymox\Custommodule\Model\ResourceModel,Data');
    }
}

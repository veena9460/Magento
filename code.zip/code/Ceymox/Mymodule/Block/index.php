<?php
namespace Ceymox\Mymodule\Block;

Class Index extends \Magento\Framework\View\Element\Template
{   
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Ceymox\Mymodule\Helper\Data $helper,
        array $data = []
    ) {
        $this->helper = $helper;
        parent::__construct($context, $data);
    }


    public function getMessage(){
        return $this->helper->getStoreConfig();
    }
}
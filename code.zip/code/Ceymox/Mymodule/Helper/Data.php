vv   <?php

namespace Ceymox\Mymodule\Helper;
use \Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{
	protected $urlBuilder;
    
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\UrlInterface $urlBuilder
    )
    {
        $this->urlBuilder = $urlBuilder;
        parent::__construct($context);
    }

       public function getStoreConfig()
       {
               return "welcome";
       }


}
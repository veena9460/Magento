<?php
namespace Ceymox\CustomerForm\Block;
class Index extends \Magento\Framework\View\Element\Template
{


	public function getMessage()
	{
		return __('Hello ');
	}

    /*public function getFormAction() {
        //return_('appsteam/index/submit');
        		return __('Hello ');

    }*/

     public function getFormAction()
    {
            // companymodule is given in routes.xml
            // controller_name is folder name inside controller folder
            // action is php file name inside above controller_name folder
        return $this->getUrl('customerform/index/submit', ['_secure' => true]);
        // here controller_name is index, action is booking
    }
}

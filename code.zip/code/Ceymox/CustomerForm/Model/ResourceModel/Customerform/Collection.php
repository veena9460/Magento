<?php
namespace Ceymox\CustomerForm\Model\ResourceModel\Customerform;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'customer_id';
	protected $_eventPrefix = 'customer_form_collection';
	protected $_eventObject = 'Customerform_collection';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct()
	{
		$this->_init('Ceymox\CustomerForm\Model\Customerform', 'Ceymox\CustomerForm\Model\ResourceModel\Customerform');
	}

}
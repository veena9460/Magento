<?php
namespace Ceymox\CustomerForm\Model;

class Customerform extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
	const CACHE_TAG = 'customer_form';

	protected $_cacheTag = 'customer_form';

	protected $_eventPrefix = 'customer_form';

	protected function _construct()
	{
		$this->_init('Ceymox\CustomerForm\Model\ResourceModel\Customerform');
	}

	public function getIdentities()
	{
		return [self::CACHE_TAG . '_' . $this->getId()];
	}

	public function getDefaultValues()
	{
		$values = [];

		return $values;
	}
}
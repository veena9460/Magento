<?php
namespace About\Page\Block;
class Index extends \Magento\Framework\View\Element\Template
{
	
}